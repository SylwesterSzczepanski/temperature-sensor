$(function() {
    $.ajax({

        url: '//your_page/temperatura/chart_data.php',
        type: 'GET',
        success: function(data) {
            chartData = data;
            var chartProperties = {
                "caption": "Value1",
                "xAxisName": "TIME",
                "yAxisName": "Value1",
                "showValues": "0",
				"setAdaptiveYMin": "1",
				"chartLeftMargin": "40",
                "chartTopMargin": "40",
                "chartRightMargin": "40",
                "chartBottomMargin": "40",
				"bgColor": "f0f0f0",
                "theme": "zune"
            };

            apiChart = new FusionCharts({
                type: 'line',
                renderAt: 'chart-container',
                width: '1600',
                height: '900',
				                dataFormat: 'json',
                dataSource: {
                    "chart": chartProperties,
                    "data": chartData
                }
            });
            apiChart.render();
        }
    });
});
